package udp

import (
  "net"
)

func ConnectTo(BridgeAddress string) (*net.UDPConn, error) {

  sourceAddr, err := net.ResolveUDPAddr("udp", "192.168.56.102:56300")
  if err != nil {
    return nil, err
  }

  destAddr, err := net.ResolveUDPAddr("udp", BridgeAddress)
  if err != nil {
    return nil, err
  }

  conn, err := net.DialUDP("udp", sourceAddr, destAddr)
  if err != nil {
    return nil, err
  }

  return conn, nil
}

func SendDataUDP(connection *net.UDPConn, data []byte) (int, error) {
  return connection.Write(data)
}
