package codes

const (
	CodeOK = iota
	CodeErrorName
	CodeErrorAddress
	CodeErrorDeviceActive
	CodeNoBridge
	CodeErrorGatewayActive
	CodeSaving
)
